package com.s1dan.tetris.constants

enum class CellConstants(val value: Byte) {
    EMPTY(0), EPHEMERAL(1)
}