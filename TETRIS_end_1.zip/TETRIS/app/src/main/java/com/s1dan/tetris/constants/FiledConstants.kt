package com.s1dan.tetris.constants

enum class FieldConstrants(val value:Int) {
    COLOMN_COUNT(10), ROW_COUNT(20);
}