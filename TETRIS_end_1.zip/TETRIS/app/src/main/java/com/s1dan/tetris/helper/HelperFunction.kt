package com.s1dan.tetris.helper

class HelperFunction() {

    public fun array2dOfByte(sizeOuter: Int, sizeInner: Int) : Array<ByteArray> = Array(sizeOuter) {
        ByteArray(sizeInner)
    }

}